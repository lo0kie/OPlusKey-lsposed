package io.github.suqi8.coui.kmp.basic

import androidx.compose.runtime.compositionLocalOf

/**
 * 「这一下点在了**禁用**的控件上」—— 由使用方提供一句解释，不提供就什么也不发生。
 *
 * ## 为什么库要开这个口子
 *
 *  禁用在本库里的做法是**连点击都不挂**（`clickableModifier` 只在 enabled 时加），于是整块
 *  界面置灰之后用户点哪儿都没反应 —— 分不清「点歪了」「卡住了」还是「这东西本来就不能用」。
 *  可「为什么不能用」只有使用方知道（业务闸门），库这边只负责把**这一下点击**递出去。
 *
 * ## 用法
 *
 *  使用方在页面根上 provide 一个「说明原因」的 lambda；库里所有**可点**的控件
 *  （`BasicComponent` / `IconButton` / 可交互 `Card` / 下拉菜单行）在 `enabled = false` 时
 *  会挂一层**没有涟漪、不改按下态**的点击，把事件交给它。
 *
 *  与「把 enabled 设成 true 再自己判断」的区别：外观、按下态、无障碍的 disabled 语义全都不变，
 *  只是多了一条「问为什么」的通道。
 */
val LocalDisabledClick = compositionLocalOf<(() -> Unit)?> { null }
